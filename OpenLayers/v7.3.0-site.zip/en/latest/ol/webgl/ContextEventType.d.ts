declare namespace _default {
    const LOST: string;
    const RESTORED: string;
}
export default _default;
//# sourceMappingURL=ContextEventType.d.ts.map